package net.mcreator.eosclient.procedure;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiTextField;

import net.mcreator.eosclient.EosClientVariables;
import net.mcreator.eosclient.ElementsEosClient;

import java.util.HashMap;

@ElementsEosClient.ModElement.Tag
public class ProcedureSetSpoofIP extends ElementsEosClient.ModElement {
	public ProcedureSetSpoofIP(ElementsEosClient instance) {
		super(instance, 8);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure SetSpoofIP!");
			return;
		}
		if (dependencies.get("guistate") == null) {
			System.err.println("Failed to load dependency guistate for procedure SetSpoofIP!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure SetSpoofIP!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap guistate = (HashMap) dependencies.get("guistate");
		World world = (World) dependencies.get("world");
		EosClientVariables.MapVariables.get(world).SpoofIP = (String) (new Object() {
			public String getText() {
				GuiTextField textField = (GuiTextField) guistate.get("text:SpoofIP");
				if (textField != null) {
					return textField.getText();
				}
				return "";
			}
		}.getText());
		EosClientVariables.MapVariables.get(world).syncData(world);
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] You spoofed your IP to:"), (false));
		}
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString((EosClientVariables.MapVariables.get(world).SpoofIP)), (false));
		}
	}
}
