package net.mcreator.eosclient.procedure;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiTextField;

import net.mcreator.eosclient.EosClientVariables;
import net.mcreator.eosclient.ElementsEosClient;

import java.util.HashMap;

@ElementsEosClient.ModElement.Tag
public class ProcedureSetSpoofName extends ElementsEosClient.ModElement {
	public ProcedureSetSpoofName(ElementsEosClient instance) {
		super(instance, 6);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure SetSpoofName!");
			return;
		}
		if (dependencies.get("guistate") == null) {
			System.err.println("Failed to load dependency guistate for procedure SetSpoofName!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure SetSpoofName!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap guistate = (HashMap) dependencies.get("guistate");
		World world = (World) dependencies.get("world");
		EosClientVariables.MapVariables.get(world).SpoofName = (String) (new Object() {
			public String getText() {
				GuiTextField textField = (GuiTextField) guistate.get("text:SpoofName");
				if (textField != null) {
					return textField.getText();
				}
				return "";
			}
		}.getText());
		EosClientVariables.MapVariables.get(world).syncData(world);
		entity.setCustomNameTag((EosClientVariables.MapVariables.get(world).SpoofName));
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] You spoofed your name to:"), (false));
		}
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString((EosClientVariables.MapVariables.get(world).SpoofName)), (false));
		}
	}
}
