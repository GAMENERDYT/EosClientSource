package net.mcreator.eosclient.procedure;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiTextField;

import net.mcreator.eosclient.ElementsEosClient;

import java.util.HashMap;

@ElementsEosClient.ModElement.Tag
public class ProcedureHacksVclip extends ElementsEosClient.ModElement {
	public ProcedureHacksVclip(ElementsEosClient instance) {
		super(instance, 19);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HacksVclip!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure HacksVclip!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure HacksVclip!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure HacksVclip!");
			return;
		}
		if (dependencies.get("guistate") == null) {
			System.err.println("Failed to load dependency guistate for procedure HacksVclip!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure HacksVclip!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		HashMap guistate = (HashMap) dependencies.get("guistate");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
		entity.setPositionAndUpdate(x, (y + new Object() {
			int convert(String s) {
				try {
					return Integer.parseInt(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((new Object() {
			public String getText() {
				GuiTextField textField = (GuiTextField) guistate.get("text:VClipNumber");
				if (textField != null) {
					return textField.getText();
				}
				return "";
			}
		}.getText()))), z);
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] V Clip Hack enabled with Distance:"), (false));
		}
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString((new Object() {
				public String getText() {
					GuiTextField textField = (GuiTextField) guistate.get("text:VClipNumber");
					if (textField != null) {
						return textField.getText();
					}
					return "";
				}
			}.getText())), (false));
		}
	}
}
