package net.mcreator.eosclient.procedure;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiTextField;

import net.mcreator.eosclient.ElementsEosClient;

import java.util.HashMap;

@ElementsEosClient.ModElement.Tag
public class ProcedureHacksHeal extends ElementsEosClient.ModElement {
	public ProcedureHacksHeal(ElementsEosClient instance) {
		super(instance, 20);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HacksHeal!");
			return;
		}
		if (dependencies.get("guistate") == null) {
			System.err.println("Failed to load dependency guistate for procedure HacksHeal!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure HacksHeal!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap guistate = (HashMap) dependencies.get("guistate");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).setHealth((float) new Object() {
				int convert(String s) {
					try {
						return Integer.parseInt(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert((new Object() {
				public String getText() {
					GuiTextField textField = (GuiTextField) guistate.get("text:HealNumber");
					if (textField != null) {
						return textField.getText();
					}
					return "";
				}
			}.getText())));
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] Heal Hack enabled"), (false));
		}
	}
}
