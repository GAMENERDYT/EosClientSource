package net.mcreator.eosclient.procedure;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.DamageSource;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScoreCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiTextField;

import net.mcreator.eosclient.EosClientVariables;
import net.mcreator.eosclient.ElementsEosClient;

import java.util.HashMap;

@ElementsEosClient.ModElement.Tag
public class ProcedureSetCrashBotAttack extends ElementsEosClient.ModElement {
	public ProcedureSetCrashBotAttack(ElementsEosClient instance) {
		super(instance, 15);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure SetCrashBotAttack!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure SetCrashBotAttack!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure SetCrashBotAttack!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure SetCrashBotAttack!");
			return;
		}
		if (dependencies.get("guistate") == null) {
			System.err.println("Failed to load dependency guistate for procedure SetCrashBotAttack!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure SetCrashBotAttack!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		HashMap guistate = (HashMap) dependencies.get("guistate");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
		EosClientVariables.MapVariables.get(world).CrashBotAttack = (String) (new Object() {
			public String getText() {
				GuiTextField textField = (GuiTextField) guistate.get("text:BotAttackF");
				if (textField != null) {
					return textField.getText();
				}
				return "";
			}
		}.getText());
		EosClientVariables.MapVariables.get(world).syncData(world);
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] Started Bot Attack using Bot Amount:"), (false));
		}
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString((EosClientVariables.MapVariables.get(world).CrashBotAttack)), (false));
		}
		if (entity instanceof EntityPlayer) {
			Scoreboard _sc = ((EntityPlayer) entity).getWorldScoreboard();
			ScoreObjective _so = _sc.getObjective("null");
			if (_so == null) {
				_so = _sc.addScoreObjective("null", ScoreCriteria.DUMMY);
			}
			Score _scr = _sc.getOrCreateScore(((EntityPlayer) entity).getGameProfile().getName(), _so);
			_scr.setScorePoints((int) 1);
		}
		entity.setPositionAndUpdate(x, (y + 2), z);
		entity.attackEntityFrom(DamageSource.FALL, (float) 3);
		for (int index0 = 0; index0 < (int) (new Object() {
			int convert(String s) {
				try {
					return Integer.parseInt(s.trim());
				} catch (Exception e) {
				}
				return 0;
			}
		}.convert((EosClientVariables.MapVariables.get(world).CrashBotAttack))); index0++) {
			if (entity instanceof EntityPlayer && !world.isRemote) {
				((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] Connecting Bot with ID:"), (false));
			}
			EosClientVariables.MapVariables.get(world).Bots = (double) ((EosClientVariables.MapVariables.get(world).Bots) + 1);
			EosClientVariables.MapVariables.get(world).syncData(world);
			if (entity instanceof EntityPlayer && !world.isRemote) {
				((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] undefined"), (false));
			}
		}
		if (entity instanceof EntityPlayer && !world.isRemote) {
			((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] Finished Bot Attack!"), (false));
		}
		EosClientVariables.MapVariables.get(world).Bots = (double) 0;
		EosClientVariables.MapVariables.get(world).syncData(world);
	}
}
