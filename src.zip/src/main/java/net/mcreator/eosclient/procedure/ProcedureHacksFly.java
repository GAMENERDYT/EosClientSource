package net.mcreator.eosclient.procedure;

import net.minecraft.world.World;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;

import net.mcreator.eosclient.EosClientVariables;
import net.mcreator.eosclient.ElementsEosClient;

@ElementsEosClient.ModElement.Tag
public class ProcedureHacksFly extends ElementsEosClient.ModElement {
	public ProcedureHacksFly(ElementsEosClient instance) {
		super(instance, 21);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HacksFly!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure HacksFly!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
		if (((EosClientVariables.MapVariables.get(world).FlyEnable) == (false))) {
			EosClientVariables.MapVariables.get(world).FlyEnable = (boolean) (true);
			EosClientVariables.MapVariables.get(world).syncData(world);
			if (entity instanceof EntityPlayer) {
				((EntityPlayer) entity).capabilities.isFlying = ((EosClientVariables.MapVariables.get(world).FlyEnable) == (true));
				((EntityPlayer) entity).sendPlayerAbilities();
			}
			if (entity instanceof EntityPlayer && !world.isRemote) {
				((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] Fly Hack enabled"), (false));
			}
		} else {
			EosClientVariables.MapVariables.get(world).FlyEnable = (boolean) (false);
			EosClientVariables.MapVariables.get(world).syncData(world);
			if (entity instanceof EntityPlayer && !world.isRemote) {
				((EntityPlayer) entity).sendStatusMessage(new TextComponentString("[EosClient] Fly Hack disabled"), (false));
			}
			if (entity instanceof EntityPlayer) {
				((EntityPlayer) entity).capabilities.isFlying = ((EosClientVariables.MapVariables.get(world).FlyEnable) == (true));
				((EntityPlayer) entity).sendPlayerAbilities();
			}
		}
	}
}
