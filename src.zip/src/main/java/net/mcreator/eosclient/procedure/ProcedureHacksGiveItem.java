package net.mcreator.eosclient.procedure;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.GuiTextField;

import net.mcreator.eosclient.ElementsEosClient;

import java.util.HashMap;

@ElementsEosClient.ModElement.Tag
public class ProcedureHacksGiveItem extends ElementsEosClient.ModElement {
	public ProcedureHacksGiveItem(ElementsEosClient instance) {
		super(instance, 33);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HacksGiveItem!");
			return;
		}
		if (dependencies.get("guistate") == null) {
			System.err.println("Failed to load dependency guistate for procedure HacksGiveItem!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap guistate = (HashMap) dependencies.get("guistate");
		if (entity instanceof EntityPlayer) {
			ItemStack _setstack = new ItemStack(Blocks.TNT, (int) (1));
			_setstack.setCount(new Object() {
				int convert(String s) {
					try {
						return Integer.parseInt(s.trim());
					} catch (Exception e) {
					}
					return 0;
				}
			}.convert((new Object() {
				public String getText() {
					GuiTextField textField = (GuiTextField) guistate.get("text:GiveItemNumber");
					if (textField != null) {
						return textField.getText();
					}
					return "";
				}
			}.getText())));
			ItemHandlerHelper.giveItemToPlayer(((EntityPlayer) entity), _setstack);
		}
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).closeScreen();
	}
}
